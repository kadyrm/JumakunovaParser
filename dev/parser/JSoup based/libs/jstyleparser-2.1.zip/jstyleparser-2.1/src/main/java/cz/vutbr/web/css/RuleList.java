/**
 * RuleList.java
 *
 * Created on 30. 6. 2014, 14:22:01 by burgetr
 */
package cz.vutbr.web.css;

import java.util.List;

/**
 * A simple list of rules.
 *  
 * @author burgetr
 */
public interface RuleList extends List<RuleBlock<?>>
{

}
