package cz.vutbr.web.csskit;

import cz.vutbr.web.css.TermNumber;

/**
 * TermIdent
 * @author Jan Svercl, VUT Brno, 2008
 * 			modified by Karel Piwko
 */
public class TermNumberImpl extends TermFloatValueImpl implements TermNumber {

	protected TermNumberImpl() {
	}
	
}
