/**
 * TermResolutionImpl.java
 *
 * Created on 2. 7. 2014, 14:57:29 by burgetr
 */
package cz.vutbr.web.csskit;

import cz.vutbr.web.css.TermResolution;

/**
 * 
 * @author burgetr
 */
public class TermResolutionImpl extends TermFloatValueImpl implements TermResolution
{
    
    protected TermResolutionImpl() 
    {
    }
    
}
